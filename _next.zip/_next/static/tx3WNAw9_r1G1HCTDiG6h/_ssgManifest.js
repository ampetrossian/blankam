self.__SSG_MANIFEST = new Set(["\u002Fphotos", "\u002Fprojects", "\u002Fwords"]);
self.__SSG_MANIFEST_CB && self.__SSG_MANIFEST_CB()