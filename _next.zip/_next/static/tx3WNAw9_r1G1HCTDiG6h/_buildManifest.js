self.__BUILD_MANIFEST = {
    __rewrites: {
        beforeFiles: [],
        afterFiles: [{
            source: "/js/script.js"
        }, {
            source: "/api/event"
        }],
        fallback: []
    },
    "/": ["static/chunks/pages/index-3adc7919344f1dbf.js"],
    "/_error": ["static/chunks/pages/_error-2280fa386d040b66.js"],
    "/photos": ["static/chunks/pages/photos-91280ac54c95bf42.js"],
    "/projects": ["static/chunks/pages/projects-4211c664e0c50312.js"],
    "/words": ["static/chunks/pages/words-ce2bce72ca9b7ffa.js"],
    "/writing": ["static/chunks/pages/writing-3593c598256cfcd7.js"],
    "/writing/growing-through-design": ["static/chunks/pages/writing/growing-through-design-0d2ca18e17ec342d.js"],
    "/writing/painting-with-the-internet": ["static/chunks/pages/writing/painting-with-the-internet-486276b06cad3fcd.js"],
    "/writing/real-artists-ship": ["static/chunks/pages/writing/real-artists-ship-9d750fa3832e4e3c.js"],
    sortedPages: ["/", "/_app", "/_error", "/photos", "/projects", "/words", "/writing", "/writing/growing-through-design", "/writing/painting-with-the-internet", "/writing/real-artists-ship"]
},
self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();
