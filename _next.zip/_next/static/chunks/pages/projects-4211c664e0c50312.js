(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[327], {
    4478: function(t, r, e) {
        (window.__NEXT_P = window.__NEXT_P || []).push(["/projects", function() {
            return e(1663)
        }
        ])
    },
    1663: function(t, r, e) {
        "use strict";
        e.r(r),
        e.d(r, {
            __N_SSG: function() {
                return c
            },
            default: function() {
                return p
            }
        });
        var i = e(5893)
          , n = e(5675)
          , o = e(4935)
          , a = e(7009);
        function s(t, r, e) {
            return r in t ? Object.defineProperty(t, r, {
                value: e,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[r] = e,
            t
        }
        var l = [{
            name: "Skolkovo Business Park",
            description: "With partnership Proximity Moscow x Assembly Studios",
            href: "https://skolkovoforbusiness.ru/en/features/#home",
            photoUrl: "/static/skolkovo.png"
        }, {
            name: "Winamp",
            description: "Intro website UI/UX Design.",
            href: "https://winamp.com",
            photoUrl: "static/winamp.png"
        }, {
            name: "Flighty App",
            description: "App Icon. Product Design.",
            href: "https://apps.apple.com/app/apple-store/id1358823008",
            photoUrl: "static/flighty.png"
        }, {
            name: "Natural AI",
            description: "The future of shopping. Product Design.",
            href: "https://apps.apple.com/us/app/id1521375720",
            photoUrl: "static/natural.png",
            variant: "border"
        }, {
            name: "Hey Email",
            description: "Email’s new heyday. UX Design.",
            href: "https://hey.com",
            photoUrl: "static/hey.png",
            fullWidth: !0,
            variant: "border"
        }, {
            name: "Fabriano",
            description: "Website UI/UX Design. Partnership with Pentagram.",
            href: "https://fabriano.com",
            photoUrl: "static/fabriano.png"
        }, {
            name: "Ziina",
            description: "Iconography for app. Website Design.",
            href: "https://ziina.com",
            photoUrl: "static/ziina.png"
        }, {
            name: "Stripe Press",
            description: "Website Design.",
            href: "https://press.stripe.com/",
            photoUrl: "static/stripe.png",
            variant: "border"
        }]
          , c = !0;
        function p(t) {
            var r = t.photos;
            return (0,
            i.jsxs)(i.Fragment, {
                children: [(0,
                i.jsx)(o.T3, {
                    title: "Projects",
                    description: (0,
                    i.jsx)(i.Fragment, {
                        children: "Internet thingies built with love."
                    })
                }), (0,
                i.jsx)(o.xu, {
                    as: "ul",
                    css: {
                        mt: "$4",
                        display: "grid",
                        gap: "24px",
                        gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))"
                    },
                    children: l.map((function(t) {
                        return (0,
                        i.jsx)(u, function(t) {
                            for (var r = 1; r < arguments.length; r++) {
                                var e = null != arguments[r] ? arguments[r] : {}
                                  , i = Object.keys(e);
                                "function" === typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(e).filter((function(t) {
                                    return Object.getOwnPropertyDescriptor(e, t).enumerable
                                }
                                )))),
                                i.forEach((function(r) {
                                    s(t, r, e[r])
                                }
                                ))
                            }
                            return t
                        }({
                            base64: r[t.photoUrl]
                        }, t, {
                            css: {
                                gridColumn: t.fullWidth ? "1 / -1" : void 0
                            }
                        }), t.href)
                    }
                    ))
                })]
            })
        }
        function u(t) {
            var r = t.href
              , e = t.photoUrl
              , a = t.name
              , s = t.description
              , l = t.css
              , c = t.variant
              , p = t.base64;
            return (0,
            i.jsxs)("a", {
                href: r,
                target: "_blank",
                rel: "noopener noreferrer",
                className: h({
                    variant: c,
                    css: l
                }),
                children: [(0,
                i.jsx)(o.xS, {
                    alt: a,
                    src: p
                }), (0,
                i.jsx)(o.xu, {
                    as: n.default,
                    src: e,
                    layout: "fill",
                    objectFit: "cover",
                    css: {
                        width: "100%",
                        height: "100%",
                        borderRadius: "12px",
                        transition: "filter 400ms cubic-bezier(.2, .8, .2, 1)"
                    }
                }), (0,
                i.jsxs)(o.xu, {
                    id: "meta",
                    css: {
                        position: "absolute",
                        opacity: 0,
                        bottom: 0,
                        left: 32,
                        transition: "bottom 400ms cubic-bezier(.2, .8, .2, 1)"
                    },
                    children: [(0,
                    i.jsx)(o.xv, {
                        as: "p",
                        weight: "700",
                        size: "24",
                        color: "gray12",
                        children: a
                    }), (0,
                    i.jsx)(o.xv, {
                        as: "span",
                        color: "gray11",
                        size: "14",
                        lineHeight: "20",
                        css: {
                            mt: "8px",
                            maxWidth: "220px"
                        },
                        children: s
                    })]
                })]
            })
        }
        var h = (0,
        a.iv)({
            br: "12px",
            display: "inline-block",
            width: "100%",
            height: "300px",
            position: "relative",
            overflow: "hidden",
            "@mobile": {
                height: "200px"
            },
            "@hover": {
                "&:hover, &:focus": {
                    img: {
                        filter: "brightness(92%) grayscale(0)",
                        ".dark &": {
                            filter: "brightness(40%)"
                        }
                    },
                    "#meta": {
                        bottom: 32,
                        opacity: 1
                    }
                }
            },
            variants: {
                variant: {
                    border: {
                        border: "2px dotted $gray6",
                        ".dark &": {
                            borderColor: "transparent"
                        }
                    }
                }
            }
        })
    }
}, function(t) {
    t.O(0, [774, 888, 179], (function() {
        return r = 4478,
        t(t.s = r);
        var r
    }
    ));
    var r = t.O();
    _N_E = r
}
]);
