(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[405], {
    5301: function(e, r, n) {
        (window.__NEXT_P = window.__NEXT_P || []).push(["/", function() {
            return n(441)
        }
        ])
    },
    441: function(e, r, n) {
        "use strict";
        n.r(r),
        n.d(r, {
            default: function() {
                return h
            }
        });
        var t = n(5893)
          , i = n(4935);
        function s(e) {
            var r = e.children;
            return (0,
            t.jsx)(i.xv, {
                as: "p",
                size: "15",
                color: "gray11",
                css: {
                    mt: "12px"
                },
                children: r
            })
        }
        function h() {
            return (0,
            t.jsxs)(t.Fragment, {
                children: [(0,
                t.jsx)(i.h_, {}), (0,
                t.jsx)(i.xv, {
                    as: "h1",
                    weight: "700",
                    size: "24",
                    color: "gray12",
                    family: "serif",
                    children: "Armen Petrossian"
                }), (0,
                t.jsx)(s, {
                    children: "UI/UX designer in love with emotional interfaces."
                }), (0,
                t.jsx)(i.Z0, {
                    css: {
                        width: "48px",
                        mb: "24px"
                    }
                }), (0,
                t.jsxs)(s, {
                    children: ["I am creating ", (0,
                    t.jsx)(i.rU, {
                        href: "https://natural.ai",
                        children: "Natural AI"
                    }), " and exploring artificial intelligence for the best user experience.", " ", (0,
                    t.jsx)(i.rU, {
                        href: "",
                        children: ""
                    }), ]
                }), (0,
                t.jsxs)(s, {
                    children: ["Design Partner at ", (0,
                    t.jsx)(i.rU, {
                        href: "https://braind.am",
                        children: "Braind Yerevan"
                    }), " &", " ", (0,
                    t.jsx)(i.rU, {
                        href: "https://metadesign.com",
                        children: "MetaDesign Berlin"
                    }), "."]
                })]
            })
        }
    }
}, function(e) {
    e.O(0, [774, 888, 179], (function() {
        return r = 5301,
        e(e.s = r);
        var r
    }
    ));
    var r = e.O();
    _N_E = r
}
]);
