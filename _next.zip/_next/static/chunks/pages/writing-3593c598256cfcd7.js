(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[823], {
    3124: function(n, _, u) {
        (window.__NEXT_P = window.__NEXT_P || []).push(["/writing", function() {
            return u(4581)
        }
        ])
    }
}, function(n) {
    n.O(0, [774, 888, 179], (function() {
        return _ = 3124,
        n(n.s = _);
        var _
    }
    ));
    var _ = n.O();
    _N_E = _
}
]);