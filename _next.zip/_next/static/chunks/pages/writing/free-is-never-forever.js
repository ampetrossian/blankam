(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[615], {
    1550: function(e, t, n) {
        (window.__NEXT_P = window.__NEXT_P || []).push(["/writing/free-is-never-forever", function() {
            return n(831)
        }
        ])
    },
    831: function(e, t, n) {
        "use strict";
        n.r(t),
        n.d(t, {
            default: function() {
                return l
            }
        });
        n(7294);
        var a = n(3905);
        function o(e, t) {
            if (null == e)
                return {};
            var n, a, o = function(e, t) {
                if (null == e)
                    return {};
                var n, a, o = {}, i = Object.keys(e);
                for (a = 0; a < i.length; a++)
                    n = i[a],
                    t.indexOf(n) >= 0 || (o[n] = e[n]);
                return o
            }(e, t);
            if (Object.getOwnPropertySymbols) {
                var i = Object.getOwnPropertySymbols(e);
                for (a = 0; a < i.length; a++)
                    n = i[a],
                    t.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(e, n) && (o[n] = e[n])
            }
            return o
        }
        var i, r = (i = "Break",
        function(e) {
            return console.warn("Component " + i + " was not imported, exported, or provided by MDXProvider as global scope"),
            (0,
            a.kt)("div", Object.assign({}, e))
        }
        ), s = {};
        function l(e) {
            var t = e.components
              , n = o(e, ["components"]);
            return (0,
            a.kt)("wrapper", Object.assign({}, s, n, {
                components: t,
                mdxType: "MDXLayout"
            }), (0,
            a.kt)("h1", null, "Free is never forever"), (0,
            a.kt)("a", Object.assign({
                parentName: "p"
            }, {
                href: "https://uiw.tf"
            }), "experiment with user interfaces"), " after growing tired of re-cycling and building the same shit again and again.\nThe intention was never to really undermine, oppose, or conduct meaningful change, but rather to tinker, have fun, and provoke an emotion."), (0,
            a.kt)("p", null, "There's just something very exciting in building novel stuff ", (0,
            a.kt)("em", {
                parentName: "p"
            }, "just for fun"), ".\nIt feels very much like a return to the roots back when I was entering this magical, technological world of infinite possibilities.\nI actually tried to become a designer at first but failed. Sitting down and working with drawing tools just didn't click for me.\nIt felt very static, foreign, and especially intimidating to stare at a blank canvas."), (0,
            a.kt)("p", null, "After being rejected a couple of times, I decided I would just build my own designs, instead. Blasting up ", (0,
            a.kt)("a", Object.assign({
                parentName: "p"
            }, {
                href: "https://codepen.com"
            }), "CodePen"), "\n5 years ago I had no idea what kind of a path I set myself on."), (0,
            a.kt)("p", null, "The intention was not to become an engineer, but to have fun by giving life to\nmy wildest dreams and ideas. Changing variables and colors in code felt fascinating and immediate. I\nhad no idea what I was doing, but it was incredible."), (0,
            a.kt)("p", null, "For some reason, those early days were some of the most fun I ever had with interfaces,\ndespite frantically googling and copy-pasting every single thing I didn't understand."), (0,
            a.kt)("p", null, "Looking back, I've also come to realize that I never ", (0,
            a.kt)("em", {
                parentName: "p"
            }, "really"), " struggled at that point. I did spend a lot of time immersed in design and code. Some days were hard, others were a breeze.\nBut it never came unnaturally or with a lot of effort to me. Maybe it's because I was just having so much fun? Or am I just merely glorifying the past?"), (0,
            a.kt)(r, {
                mdxType: "Break"
            }), (0,
            a.kt)("p", null, "Today, I am working remotely from ", (0,
            a.kt)("a", Object.assign({
                parentName: "p"
            }, {
                href: "https://www.google.com/search?q=florianopolis+brazil&sxsrf=AOaemvJAQPWMBF3Vv3jKFlUIL4hOjFmn-A:1636674346514&source=lnms&tbm=isch&sa=X&ved=2ahUKEwi0r6WIv5H0AhVPqZUCHZntCycQ_AUoAXoECAEQAw&biw=1660&bih=1005&dpr=2"
            }), "Florianopolis, Brazil"), ".\nI moved here around 3 months ago temporarily from Estonia just to explore, feel, and experience something new. So far, my creativity and inspiration have been through the roof.\nIt's not like I wasn't doing anything back home, but new environments seem to trigger and spark new ideas, like ", (0,
            a.kt)("a", Object.assign({
                parentName: "p"
            }, {
                href: "https://ultra.tf"
            }), "Ultra"), ". I think it's also because I'm here completely solo."), (0,
            a.kt)("p", null, "It's kind of funny because seemingly I'm not in the midst of productivity.\nI don't have a dedicated workspace with a 5K display, external keyboard, ergonomic chair, and a standing desk that can launch into space.\nThe primary spaces of creativity for me are a hammock on the terrace, a small kitchen table, or a dresser which I sometimes use as a standing desk.\nPowered by a 13\" MacBook Pro,\n", (0,
            a.kt)("a", Object.assign({
                parentName: "p"
            }, {
                href: "https://en.wikipedia.org/wiki/Bursera_graveolens"
            }), "palo santo"), ",\n", (0,
            a.kt)("a", Object.assign({
                parentName: "p"
            }, {
                href: "https://en.wikipedia.org/wiki/Kombucha"
            }), "kombucha"), ", and a dude with hyperfocus. Welcome to Brazil."), (0,
            a.kt)("p", null, "Though, I don't claim to be on the brink of genius and supreme motivation consistently. There are days where I don't feel like doing anything or moments where I don't love anything I do.\nIt's a ride."), (0,
            a.kt)(r, {
                mdxType: "Break"
            }), (0,
            a.kt)("p", null, "Anyway, coming to Brazil I was planning to just chill and create some cool stuff.\nAfter some time we got in touch with ", (0,
            a.kt)("a", Object.assign({
                parentName: "p"
            }, {
                href: "https://twitter.com/joshm"
            }), "Josh"), " about the experiments I was sharing on ", (0,
            a.kt)("a", Object.assign({
                parentName: "p"
            }, {
                href: "https://twitter.com/raunofreiberg"
            }), "Twitter"), ".\nAt that point I wasn't super keen on a change because it meant pursuing something new and unknown.\nI mean, I've never touched Swift in my life and the comfort zone is, well... comfortable!"), (0,
            a.kt)("p", null, "But the more I got to know Josh and learn about the sort of philosophy embedded in their family of digital artists,\nI was starting to feel a connection through a throwback to the early days of building interfaces where it was all about having fun through experimentation and prototyping.\nIt felt like the right place to grow as a human, engineer, and designer."), (0,
            a.kt)("p", null, "Three months ago packing exclusively for sunshine and rainbows I would not have guessed that my next destination would be New York,\nand I would be switching jobs while travelling, about to learn Swift as a Design Engineer at ", (0,
            a.kt)("a", Object.assign({
                parentName: "p"
            }, {
                href: "https://thebrowser.company/"
            }), "The Browser Company"), "."), (0,
            a.kt)("p", null, "We can plan, dream, and hope that we know what the future holds for us but truth be told: life has a way of knocking on the door with its own plan.\nYeah, I do recognize the esotericism here so let me be candid..."), (0,
            a.kt)("p", null, "I don't know what the future holds and I might fail, but what I've learned so far is that opportunities that have found their way organically to me have always proven to eventually teach me something, whatever that may be."), (0,
            a.kt)("p", null, "It's hard, but ultimately I think it's worth trusting in life and your gut."))
        }
        l.isMDXComponent = !0
    }
}, function(e) {
    e.O(0, [774, 888, 179], (function() {
        return t = 1550,
        e(e.s = t);
        var t
    }
    ));
    var t = e.O();
    _N_E = t
}
]);
